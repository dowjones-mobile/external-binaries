#import <UserMessagingPlatform/UMPConsentForm.h>
#import <UserMessagingPlatform/UMPConsentInformation.h>
#import <UserMessagingPlatform/UMPDebugSettings.h>
#import <UserMessagingPlatform/UMPError.h>
#import <UserMessagingPlatform/UMPRequestParameters.h>
