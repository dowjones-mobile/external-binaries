//
//  APSExternalUserId.h
//  DTBiOSSDK
//
//  Copyright © 2026 amazon.com. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class APSExternalUniqueId;

/**
 * Represents a third-party external user ID to be passed in bid requests.
 * Use the builder methods to construct an instance.
 *
 * Example:
 * @code
 * APSExternalUserId *userId = [[[[APSExternalUserIdBuilder builder]
 *     addSource:@"liveramp.com"]
 *     addUniqueId:@"abc123" atype:@3 ext:@{@"provider": @"liveramp.com"}]
 *     build];
 * @endcode
 *
 * A brokered ID sharing the same source can be differentiated with the inserter, matcher, and mm
 * fields:
 * @code
 * APSExternalUserId *brokered = [[[[[[[APSExternalUserIdBuilder builder]
 *     addSource:@"criteo-hemapi.com"]
 *     addUniqueId:@"abc123" atype:@3 ext:nil]
 *     addInserter:@"optable.co"]
 *     addMatcher:@"weather.com"]
 *     addMm:@3]
 *     build];
 * @endcode
 */
@interface APSExternalUserId : NSObject

/**
 * The source of this external user ID (e.g. "liveramp.com", "id5-sync.com").
 */
@property (nonatomic, copy, readonly) NSString *source;

/**
 * The list of unique IDs associated with this source.
 */
@property (nonatomic, copy, readonly) NSArray<APSExternalUniqueId *> *uids;

/**
 * The canonical domain of the entity that added this ID to the payload (e.g. "optable.co").
 * Optional. Used to differentiate a brokered ID from a raw ID sharing the same source.
 */
@property (nonatomic, copy, readonly, nullable) NSString *inserter;

/**
 * The canonical domain of the entity that performed the match (e.g. "weather.com"). Optional.
 */
@property (nonatomic, copy, readonly, nullable) NSString *matcher;

/**
 * The match method (mm) used by the matcher, per the IAB Extended Identifiers spec. Optional.
 */
@property (nonatomic, copy, readonly, nullable) NSNumber *mm;

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

/**
 * @return A JSON-compatible dictionary following the oRTB eids format.
 */
- (NSDictionary *)toJson;

@end

/**
 * Represents a single unique ID entry within an APSExternalUserId.
 */
@interface APSExternalUniqueId : NSObject

@property (nonatomic, copy, readonly) NSString *uid;
@property (nonatomic, copy, readonly, nullable) NSNumber *atype;
@property (nonatomic, copy, readonly, nullable) NSDictionary<NSString *, NSString *> *ext;

- (instancetype)init NS_UNAVAILABLE;
+ (instancetype)new NS_UNAVAILABLE;

- (NSDictionary *)toJson;

@end

/**
 * Builder for constructing APSExternalUserId instances.
 */
@interface APSExternalUserIdBuilder : NSObject

/**
 * @return A new builder instance.
 */
+ (instancetype)builder;

/**
 * Sets the source for this external user ID. Required.
 *
 * @param source The source string (e.g. "liveramp.com").
 * @return The builder instance for chaining.
 */
- (APSExternalUserIdBuilder *)addSource:(NSString *)source;

/**
 * Adds a unique ID entry.
 *
 * @param uid The unique identifier string. Required.
 * @param atype The agent type (nullable).
 * @param ext Additional extension metadata (nullable).
 * @return The builder instance for chaining.
 */
- (APSExternalUserIdBuilder *)addUniqueId:(NSString *)uid
                                     atype:(NSNumber * _Nullable)atype
                                       ext:(NSDictionary<NSString *, NSString *> * _Nullable)ext;

/**
 * Adds a unique ID entry without atype or ext.
 *
 * @param uid The unique identifier string. Required.
 * @return The builder instance for chaining.
 */
- (APSExternalUserIdBuilder *)addUniqueId:(NSString *)uid;

/**
 * Adds a unique ID entry with atype but no ext.
 *
 * @param uid The unique identifier string. Required.
 * @param atype The agent type (nullable).
 * @return The builder instance for chaining.
 */
- (APSExternalUserIdBuilder *)addUniqueId:(NSString *)uid atype:(NSNumber * _Nullable)atype;

/**
 * Sets the inserter — the canonical domain of the entity that added this ID (e.g. "optable.co").
 * Optional. Serialized at the EID level, alongside source.
 *
 * @param inserter The inserter domain string.
 * @return The builder instance for chaining.
 */
- (APSExternalUserIdBuilder *)addInserter:(NSString *)inserter;

/**
 * Sets the matcher — the canonical domain of the entity that performed the match (e.g. "weather.com").
 * Optional. Serialized at the EID level, alongside source.
 *
 * @param matcher The matcher domain string.
 * @return The builder instance for chaining.
 */
- (APSExternalUserIdBuilder *)addMatcher:(NSString *)matcher;

/**
 * Sets the match method (mm) used by the matcher, per the IAB Extended Identifiers spec. Optional.
 * Serialized at the EID level, alongside source.
 *
 * @param mm The match method value.
 * @return The builder instance for chaining.
 */
- (APSExternalUserIdBuilder *)addMm:(NSNumber *)mm;

/**
 * Builds and returns the APSExternalUserId.
 * Source must be set before calling build.
 *
 * @return A configured APSExternalUserId instance, or nil if source is not set.
 */
- (APSExternalUserId * _Nullable)build;

@end

NS_ASSUME_NONNULL_END
