//
//  ApsBidderSDKInitializationStatus.h
//  DTBiOSSDK
//
//  Created by Gaonkar, Aditya on 9/25/25.
//  Copyright © 2025 amazon.com. All rights reserved.
//
#import <Foundation/Foundation.h>

#ifndef ApsBidderSDKInitializationStatus_h
#define ApsBidderSDKInitializationStatus_h

typedef NS_ENUM(NSInteger, ApsBidderSDKInitializationStatus) {
    ApsBidderSDKInitializationStatusSuccess,
    ApsBidderSDKInitializationStatusFailure,
};
#endif /* ApsBidderSDKInitializationStatus_h */
